# mds extractor to extract elements

library(seqinr)
library(bios2mds)
#setwd("/Users/Alex/Documents/honours/cas9_bioinformatics/cleaned_base alignment_and_mds")
my_mds <- readRDS("cpf1_224_mds.rds")
mds_coords <- my_mds$coord

i <- 1
collector_frame <- data.frame()
x1 = -2
x2 = 1.3
y1 = 1.2
y2 = 5
while (i <= length(row.names(mds_coords))) {
	if ((mds_coords$PC1[i] > x1) && (mds_coords$PC1[i] < x2) && (mds_coords$PC2[i] > y1) && (mds_coords$PC2[i] < y2)) {
	collector_frame <- rbind(collector_frame, mds_coords[i, ])
	print(collector_frame)
	}
	i <- i + 1
}
write.csv(collector_frame, "final_cpf1_group_blue.csv")
collector_vector <- c(row.names(collector_frame))
write.csv(collector_vector, "final_cpf1_blue_names.csv")



