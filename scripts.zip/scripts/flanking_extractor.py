# flanking_extractor

from Bio import SeqIO
import sys

query_url = sys.argv[1]
print (query_url)
query_hit = SeqIO.read(query_url, "fasta")
flanking_regions = list(SeqIO.parse("formatted_full_metagenome_flanking.fasta", "fasta"))

flanking_regions_dict = {}
for window in flanking_regions:
	flanking_regions_dict[window.id] = window
print ("Hi")
# may need to set this
window_id = query_hit.description.split("::")
window_id = window_id[0]
print(window_id)
window_id = window_id.split(" ")
print(window_id)
window_id = window_id[1]
	#flanking_regions_dict[window_id] = window

SeqIO.write (flanking_regions_dict[window_id], query_url + "flanking.fa", "fasta")
