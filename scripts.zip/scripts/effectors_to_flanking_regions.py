# effectors_to_flanking_regions
# use the id from an effector protein to extract the corresponding flanking region
from Bio import SeqIO
import sys

effector_url = sys.argv[1]
flanking_url = sys.argv[2]

effectors = list(SeqIO.parse(effector_url, "fasta"))
flanking_regions = list(SeqIO.parse(flanking_url, "fasta"))

# both effectors and flanking_regions are dictionariable.
flanking_region_dict = {}

for flank in flanking_regions: