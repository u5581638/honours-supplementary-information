# parallelised version of flanking extractor that avoids so many memory transfers

from Bio import SeqIO
import sys
from multiprocessing import Pool


seq_url = sys.argv[1]
flanking_regions = list(SeqIO.parse(seq_url, "fasta"))
print("primed")
#create a dictionary
flanking_regions_dict = {}
for window in flanking_regions:
	flanking_regions_dict[window.id] = window
i = 0
flanking_contigs = list(SeqIO.parse("non_redundant_2nd_attempt_all_flanking_regions.fa", "fasta"))
print("ready")
ret_list = []
while (i < len(flanking_contigs)):
	query_hit = flanking_contigs[i]
	window_id = query_hit.description.split("::")
	window_id = window_id[0]
#	print(window_id)
	window_id = window_id.split(" ")
#	print(window_id)
	window_id = window_id[1]
	#flanking_regions_dict[window_id] = window
	ret_list.append(flanking_regions_dict[window_id])
	print (i)
	i += 1
SeqIO.write (ret_list,  seq_url + "_flanking.fna", "fasta")
