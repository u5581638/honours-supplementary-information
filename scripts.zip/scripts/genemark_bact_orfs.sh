#genemark bash script

bact_arr=($( ls ))
arr_len=${#bact_arr[*]}
i=0
while [ $i -lt $arr_len ] 
do ../gmhmmp -m ../MetaGeneMark_v1.mod -o $i"info.lst" -a -A $i"_protein.fa" ${bact_arr[i]}
(( i++ )) 
done 
