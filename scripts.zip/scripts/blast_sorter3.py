# algorithm to recognise duplicate entries in BLAST files and sort candidate cas proteins
# per both pident and presence in lists. Only hits with the highest entry >20% should be excluded
from Bio import SeqIO
import csv

#def in_cmd (query, seq_list):
#	print (query, seq_list)
#	i = 0
#	while (i < len(seq_list)):
#		if (query == seq_list[i]):
#			return (True, i)
#		else:
#			i += 1
#	return (False, -1)			

def grouper(csv_table):
	
	return #list of group csv sequences per qident

sequences = list(SeqIO.parse("appended_filtered_750_orfs.fasta", "fasta"))
# want a 2D matrix of csv entries
with open('master_blast_file', newline='') as csvfile:
	blastreader = list(csv.reader(csvfile)) # may need more arguments
#for row in blastreader:
#	print (row)
print("Hello")
hit_query_list = []

#function to group csv_elements goes here
for row in blastreader:
	hit_query_list.append(row[0])

hit_query_list = set(hit_query_list)
print (hit_query_list)
for hit in hit_query_list:
	print (hit + '\n')

inclusion_list = []
exclusion_list = []
i = 0
while i < len(sequences):
	if sequences[i].id in hit_query_list:
		inclusion_list.append(sequences[i])
	elif sequences[i].id not in hit_query_list:
		exclusion_list.append(sequences[i])
	else:
		print("error, missed case statement-program faulty")
	i += 1	
print(len(inclusion_list))
print(len(exclusion_list))
SeqIO.write(inclusion_list, "inclusion_list.fasta", "fasta")
SeqIO.write(exclusion_list, "exclusion_list.fasta", "fasta")		
			
