# new iterator to redundant sequence remover
# script to remove redundant sequences from the file prior to multiple alignment
from Bio import *
from Bio import SeqIO
from Bio import pairwise2
# calculates the sequence similarity between sequences

def delength (sequence):
	i = 0
	count = 0
	while (i < len(sequence)):
		if (sequence[i] == '-'): # if it's a gap 
			pass
		else:
			count += 1
		i += 1		
	return count # return sequence length without gaps	

def sequence_similarity (pairwise_alignment, len_seq1, len_seq2):
	pairwise_alignment = list(pairwise_alignment) # converting Align/SeqRecord objects to list
	i = 0 # iterator
	stop = 0 # end of sequence (same length for both sequences if alignment object)
	similarity_score = 0 # 
	divider = 0 #number to divide the similarity by
	# find the longest sequence to divide with
	if (len_seq1 < len_seq2): # compare the length of both sequences
		stop = len(pairwise_alignment[0]) # in alignment sequences are equal length
		divider = len_seq2 # divide by the longer true sequence to get a conservative estimate of identity.
	else:
		stop = len(pairwise_alignment[1].seq)
		divider = len_seq1
# directly compare the similarity between the two sequences by in order comparison.
	

	while (i < stop):
		if(pairwise_alignment[0].seq[i] == '-' and pairwise_alignment[1].seq[i] == '-'):
			pass
		elif (pairwise_alignment[0].seq[i] == pairwise_alignment[1].seq[i]):
			similarity_score += 1
	#		print (similarity_score)
		i += 1
	return (similarity_score / float(divider))		

# start of iterative code

cas9_sequences = list(SeqIO.parse("Alex_cas9_alignment_third.fasta", "fasta")) # load sequences as SeqRecord objects
percent_id_threshold = 0.99

cas9_sequences = cas9_sequences[::-1]

cas9_sequence_lengths = []
m = 0
for sequ in cas9_sequences:
	cas9_sequence_lengths.append(delength(sequ))
	print("done")
	print (m)
	m += 1

i = len(cas9_sequences) - 1 # due to zero indexing



	
redundant_sequences = []
while ( i >= 0):
	pairwise_alignment = cas9_sequences[i], cas9_sequences[i-1] # lucky that worked <- immutable types
	seq_sim = sequence_similarity (pairwise_alignment, cas9_sequence_lengths[i], cas9_sequence_lengths[i-1])
	if (seq_sim > percent_id_threshold):
		print ("good")
		redundant_sequences.append(cas9_sequences[i])
		cas9_sequences.remove(cas9_sequences[i])
		print(len(cas9_sequences))
	i -= 1	

column_index = len(cas9_sequences) - 1
while (column_index >= 0):
	print (column_index)
	row_index = column_index - 1
	while (row_index >= 0): # do not want to include self comparison
	#	print (row_index)
	#	print (column_index)
		pairwise_alignment = [cas9_sequences[row_index], cas9_sequences[column_index]] # this is probably the problem. 
		seq_sim = sequence_similarity(pairwise_alignment, cas9_sequence_lengths[row_index], cas9_sequence_lengths[column_index]) # 
#		print (seq_sim)
		if (seq_sim > percent_id_threshold):
			print ("Hi")

			redundant_sequences.append(cas9_sequences[column_index]) # add new 
			cas9_sequences.remove(cas9_sequences[column_index])
			cas9_sequence_lengths.remove(cas9_sequence_lengths[column_index])
			print(len(cas9_sequences))
			break
		else:
			row_index -= 1
#		print (row_index)	
	column_index -= 1
#	print ("Update" + str(len(cas9_sequences)))

SeqIO.write(cas9_sequences, "Alex_cas9_blind_non_redundant_sequences.fasta", "fasta")
SeqIO.write(redundant_sequences, "Alex_cas9_blind_redundant99_sequences.fasta", "fasta")

# mutual gaps are not counted

