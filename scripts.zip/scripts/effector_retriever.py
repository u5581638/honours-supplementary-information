# effector retriever

from Bio import SeqIO
import sys

cas_protein_url = sys.argv[1]
effector_protein_url = sys.argv[2] 

cas_proteins = list(SeqIO.parse(cas_protein_url, "fasta"))
effector_proteins = list(SeqIO.parse(effector_protein_url, "fasta"))
print(len(effector_proteins))
print(len(cas_proteins))
# can make cas proteins into a dict as there should be max one (and always one)
# for each effector

cas_protein_dict = {}

for cas in cas_proteins:
	cas_id = cas.description.split("::")
	cas_id = cas_id[0]
	cas_id = cas_id.split(" ")
	cas_id = cas_id[1]
	cas_protein_dict[cas_id] = cas

ret_effector_proteins = []

# effector proteins matching
for effector in effector_proteins:
	effector_id = effector.description.split("::")
	effector_id = effector_id[0]
	effector_id = effector_id.split(" ")
	effector_id = effector_id[1]
	if (effector_id in cas_protein_dict):
		ret_effector_proteins.append(effector)
		#print (effector_id)	
print(len(ret_effector_proteins))		
SeqIO.write(ret_effector_proteins, "retrieved_" + effector_protein_url, "fasta")


