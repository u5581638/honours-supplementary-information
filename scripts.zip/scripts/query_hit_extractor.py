# extract hits for query from csv
# take the shortlist and use the queries 

import csv
import sys

sys_url = sys.argv[1]
with open('2nd_fmt.csv', newline='') as csvfile:
	blastreader = list(csv.reader(csvfile)) 
queries = []
for row in blastreader:
	queries.append(row[0])


