from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import SingleLetterAlphabet
import sys

sys_url = sys.argv[1]
def stripper(seq):
#	print(seq)
	seq = list(seq)
	i = len(seq) - 1
	while (i >= 0):
		if(seq[i] == '-'):
			seq.remove(seq[i])
		i -= 1

	return "".join(seq)		

alignment = list(SeqIO.parse(sys_url, "fasta"))
i = 0
while (i < len(alignment)):
#	print (alignment[i])
	alignment[i].seq = Seq(stripper(alignment[i].seq), SingleLetterAlphabet())
#	print(alignment[i])
	print(i)
	i += 1
SeqIO.write(alignment, "dealigned" + sys_url, "fasta")	