# algorithm to construct a list of commands to SAMtools if 

from Bio import SeqIO
import re

file = open("arr_names.txt", "r") # CRISPR array file names
file2 = open("genome_names.txt", "r") # corresponding fasta sequence file names
arr_crispr = []
seq_genomes = []
crispr_arr_names = file.read()
arr_crispr = crispr_arr_names.split('\n')
print(arr_crispr)
seq_names = file2.read()
seq_genomes = seq_names.split('\n')
print(seq_genomes)
print(len(arr_crispr))
print(len(seq_genomes))
file.close()
file2.close()
i = 0
while (i < len(arr_crispr)):
        print ("master_dir/" +seq_genomes[i])
        crispr_arrays = list(SeqIO.parse("seq_indexes/" + arr_crispr[i], "fasta")) # get crispr array file
        genomes = list(SeqIO.parse("master_dir/" + seq_genomes[i], "fasta")) # get corresponding fasta file of genomes
        genomes_dict = {}
        genome_lengths = []
        for genome in genomes:
                genomes_dict[genome.id] = genome # create a dictionary of each genome
        for crispr in crispr_arrays:
                genome_lengths.append(len(genomes_dict[crispr.id].seq)) # find the lengths of each CRISPR in the genome
        k = 0
        bwa_arr = [] # container for CRISPR arrays close to genome ends
        extract_arr = [] # container for CRISPR arrays in a contig with a surrounding 40kb window
        id_list_bwa = [] # container for bwa ids
        seq_index_list_bwa = [] # container for bwa indexes
        id_list_extract = [] # container for Ids of sequences with 40kb window
        seq_index_list_extract = [] # container for indices of sequences with 40kb window
        bwa_contigs = [] # container for bwa contigs
        extract_contigs = [] # container for contigs with corresponding to a CRISPR array with a 40kb window
        while (k < len(crispr_arrays)):
                pattern = re.compile("Pos=.*]")
                index = re.search(pattern, crispr_arrays[k].description)
                index = index.group(0)
                index = int(index[4:-1])
                if (index < 20000 or genome_lengths[k] - index < 20000): #lengths should be in the same order as CRISPR arrays
                        bwa_arr.append(crispr_arrays[k])
                        id_list_bwa.append(crispr_arrays[k].id)
                        seq_index_list_bwa.append(index)
                        bwa_contigs.append(genomes_dict[crispr_arrays[k].id])
                else:
                        extract_arr.append(crispr_arrays[k]) # genomes[k]
                        id_list_extract.append(crispr_arrays[k].id)
                        seq_index_list_extract.append(index)
                        extract_contigs.append(genomes_dict[crispr_arrays[k].id])
                k += 1
        SeqIO.write(bwa_arr,  "for_flanking/bwa_arr_" + arr_crispr[i], "fasta")
        SeqIO.write(extract_arr, "for_flanking/extraction_arr_" + arr_crispr[i], "fasta")
        SeqIO.write(bwa_contigs, "for_flanking/bwa_contigs" + arr_crispr[i],  "fasta")
        SeqIO.write(extract_contigs, "for_flanking/extract_contigs" + arr_crispr[i],  "fasta")
        extract_file = open("for_flanking/ext_indices" + arr_crispr[i], "w")
        extract_cat = []
        k = 0
        while (k < len (id_list_extract)):
                extract_cat.append(id_list_extract[k] + ":" + str(seq_index_list_extract[k] - 20000) + "-" + str(seq_index_list_extract[k]+20000) + " ")
                k+=1
        extract_file.write("".join(extract_cat))
        extract_file.close()
        i += 1
