# alignment_from_mds

from Bio import SeqIO
import csv
import sys

alignment_url = sys.argv[1]
csv_url = sys.argv[2]

alignment = list(SeqIO.parse(alignment_url, "fasta"))
id_names = []
with open(csv_url, newline = '') as csvfile:
	names = csv.reader(csvfile)
	for name in names:
		id_names.append(name[1])
print(id_names)

for seq in alignment:
	print(seq.id)
collection_list = []

for seq in alignment:
	for name in id_names:
		if(seq.id == name):
			collection_list.append(seq)
print(collection_list)
print(len(collection_list))
SeqIO.write(collection_list, csv_url[:-9] + "_alignment.fasta", "fasta")			


