#cluster filterer
from Bio import SeqIO
import re
import sys
import pickle

cluster_list = sys.argv[1]  
rep_prot_list = sys.argv[2]
i = 0
motif = re.compile('gene.+_aa')
motif2 = re.compile('.+_aa')
all_clustered_proteins_list = list(SeqIO.parse(cluster_list, "fasta")) # list of proteins from CD hit
#first better check this worked as intended
gene_ids = []
representative_proteins = list(SeqIO.parse(rep_prot_list, "fasta")) # representative protein fasta file from CD-HIT
for cluster in all_clustered_proteins_list: # iterate over each cluster using SeqIO to extract each cluster
	print(i)
	cluster_str = str(cluster.seq) # convert Seq object to str
	cluster_lines = cluster_str.split('>') # split based on > in seq
	for subcluster in cluster_lines: # look through > delimited lines
	#	print (subcluster)
		ret_str = re.search(motif, subcluster) # extract gene identifer
		if (ret_str == None): # should be one case (first element from split) where none is found
			continue
		ret_str = ret_str.group(0) # extract matches from re.iter.object
		gene_ids.append(ret_str) # append matches to gene ids
	i += 1	

print(gene_ids)
#print(len(gene_ids))
#print(len(list(set(gene_ids))))
#gene_ids = list(set(gene_ids)) # this is a dodgy as all hell fix
# we have a list of identifiers.
# Now we just need to match against each representative protein identifier
ret_list = [] 
#could reformat this as a hash search
#problem is now solely here!!
count = 0
representative_protein_dict = {}
for protein in representative_proteins:
	identifier = re.search(motif2, protein.id)
	identifier =identifier.group(0)
	representative_protein_dict[identifier] = protein
i = 0
while(i < len(gene_ids)):
	if (gene_ids[i] in representative_protein_dict):
		ret_list.append(representative_protein_dict[gene_ids[i]])
		print(gene_ids[i])
		representative_protein_dict.pop(gene_ids[i])
		gene_ids.remove(gene_ids[i])
	else:
		i += 1	
print(len(representative_proteins))
print(len(ret_list))		
SeqIO.write(ret_list, "degenerate_sequence_cluster_copies_3.fasta", "fasta")			
# list of representative protein sequences to return. 
# these should be from a sorted clustering file.


