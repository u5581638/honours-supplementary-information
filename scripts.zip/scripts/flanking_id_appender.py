# flanking_id_appender
# script to append the identifier from samtools into the main descriptor as to be 
# usable in regular programming

from Bio import SeqIO
import re
import sys

input_id = sys.argv[1]
sequences = list(SeqIO.parse(input_id, "fasta"))

seq_ids = []

for seq in sequences:
	seq_ids.append(seq.description)

ret_ids = []
sequence_id = re.compile('>.*') # check re is correct	
#print(sequence_id)
for seq in seq_ids:
#	print (seq)
	re_str = re.search(sequence_id, seq) # maybe need slicing line to extract id from re
#	print(re_str)
	re_str = re_str.group(0)
	seq = re_str[1:] + '::' + seq  # add id to start of list
	seq = seq.split('>')
	seq = str(seq[0])
	print(seq)
	#seq = str(seq[0])
	
	ret_ids.append(seq)

ret_seqs = []
i = 0
while (i < len(sequences)):
	sequences[i].description = ret_ids[i]
	ret_seqs.append(sequences[i])
	i += 1
#print(ret_seqs)
SeqIO.write(sequences, "appended_" + input_id, "fasta")

