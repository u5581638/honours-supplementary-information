# article to take a list of effector proteins and return 
# identified proteins of the same id and flanking region

from Bio import SeqIO

effectors = list(SeqIO.parse("", "fasta"))
seq_collection = list(SeqIO.parse("", "fasta"))

seq_collection_dict = {}

effector_ids = []
for effector in effectors:
	iD = effector.description.split(" ")
	effector_ids.append(iD[0])
seq_ids = []
for seq in seq_collection:
	iD = seq.description.split(" ")
	seq_ids.append(iD[0])

ret_list = []
i = 0
while (i < len(effectors)):
	sp_flanking_region = []
	k = 0
	sp_flanking_region.append(effectors[i]) # creates two effector sequences in the same group
	while (k < len(seq_collection)):
		if (effector_ids[i] == seq_ids[k]):
			sp_flanking_region.append(seq_collection[k])
		k += 1
	ret_list.append(sp_flanking_region)
	i += 1
print(len(ret_list))	
# need to flatten prior to writing to file.
# BLASTing could reveal ratio of ancillary proteins to interference proteins




