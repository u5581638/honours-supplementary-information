# rm duplicates
from Bio import SeqIO
import sys

seq_url = sys.argv[1]
sequences = list(SeqIO.parse(seq_url, "fasta"))

seq_ids = []

for sequ in sequences:
	seq_ids.append(sequ.id)

seq_ids2 = set(seq_ids)

b=filter(lambda x: x not in seq_ids2, seq_ids)
print(list(b))		