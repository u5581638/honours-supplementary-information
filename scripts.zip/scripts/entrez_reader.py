#entrez reader

from Bio import Entrez
from Bio import SeqIO



Entrez.email = "u5581638@anu.edu.au"
record = Entrez.read(Entrez.elink(db="nucleotide", dbfrom="protein", id="WP_072238933.1"))
#print(record[0])
first_entry = record[0]
setdb = first_entry['LinkSetDb']
print(setdb[0])
setdb=setdb[0]
setdb=setdb['Link']
print('\n')
print(setdb)
setdb=setdb[0]
setdb=setdb['Id']
print(setdb)
handle = Entrez.efetch(db="nucleotide", id=setdb, rettype="fasta", retmode="text" )
nuc_sequence = SeqIO.read(handle, "fasta")
print(handle.read())
# that's how you extract the nucleotide sequence
# now we want to do this for all

