#cluster filterer
from Bio import SeqIO
import re
import sys
import pickle
import numpy

cluster_list = sys.argv[1]  
rep_prot_list = sys.argv[2]
i = 0
motif = re.compile('gene.+_aa')
motif2 = re.compile('.+_aa')
ranking_index_motif = re.compile('aa.[+, -]\|.*\|') # might take a bit of tinkering to get the pattern right
all_clustered_proteins_list = list(SeqIO.parse(cluster_list, "fasta")) # list of proteins from CD hit
gene_ids = []
representative_proteins = list(SeqIO.parse(rep_prot_list, "fasta")) # representative protein fasta file from CD-HIT
for cluster in all_clustered_proteins_list:
	print(i)
	cluster_str = str(cluster.seq) 
	cluster_lines = cluster_str.split('>') 
	cluster_ids = []
	cluster_ranks = []
	for subcluster in cluster_lines: # look through > delimited lines
		g_ranking = re.search(ranking_index_motif, subcluster)
		if(g_ranking == None): # should be one case (first element from split) where none is found
			continue
		g_ranking = g_ranking.group(0)
		g_ranking = int(g_ranking[4:])	
		cluster_ranks.append(g_ranking)
		ret_str = re.search(motif, subcluster) # extract gene identifer
		if (ret_str == None): # should be one case (first element from split) where none is found
			continue
		ret_str = ret_str.group(0) # extract matches from re.iter.object
		cluster_ids.append(ret_str) 
	# average the rankings
	# assign each ranking to gene_ids
	average_rank = 0
	prox_ranks = []
	for rank in cluster_ranks:
		prox_ranks.append(abs(rank - 20000))
	average_rank = float(numpy.mean(prox_ranks))
	tuple_cluster_ids = []
	for clust in cluster_ids:
		tuple_cluster_ids.append((average_rank, clust))
	gene_ids.extend(tuple_cluster_ids)	
		
	# index the average ranking from to gene_id	
	i += 1	
print(gene_ids)

# Now we just need to match against each representative protein identifier
count = 0
representative_protein_dict = {}
for protein in representative_proteins:
	identifier = re.search(motif2, protein.id)
	identifier =identifier.group(0)
	representative_protein_dict[identifier] = protein
i = 0
# seaching for gene_ids in dictionary
ret_list = [] # modify this list to be a tuple of clusters, along 
# with their average ranking 
while(i < len(gene_ids)):
	if (gene_ids[i][1] in representative_protein_dict):
		ret_list.append((gene_ids[i][0], representative_protein_dict[gene_ids[i][1]]))
		print(gene_ids[i])
		representative_protein_dict.pop(gene_ids[i][1])
		gene_ids.remove(gene_ids[i])
	else:
		i += 1	
# should have a list of gene_ids and their corresponding ranks
# need to sort ret_list according to ranks
ret_list.sort(key= lambda a : a[0]) #sort based on smallest distance from CRISPR array
new_ret_list = []
for ret in ret_list:
	new_ret_list.append(ret[1])
print(len(representative_proteins))
print(len(new_ret_list))		
print(len(list(set(new_ret_list))))	
SeqIO.write(new_ret_list, "degenerate_sequence_cluster_copies_3.fasta", "fasta")			
# list of representative protein sequences to return. 
# these should be from a sorted clustering file.


