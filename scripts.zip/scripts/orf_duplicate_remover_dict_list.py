# orf_duplicate_remover
# remove proteins predicted from two overlapping windows
# no way to align the contigs against each othepredicted orfs or contigs against each other.
# simple way is to group sequences based on the contig, then eliminate proteins from the same contig with possess exactly the
# same size.
# need to append sequences prior to performing this operation.

from Bio import SeqIO
import sys

#1. sort proteins based on organism_id -> use split
# want a single key to map to a value which is a list of sequences with the same id.
# can you dict comparison to compare matched elements with past elements
# go through every element in the list adding to dict if organism matches previous key
seq_url = sys.argv[1]

sequences = list(SeqIO.parse(seq_url, "fasta"))
organisms_dict = {}
print(len(sequences))
i = 0
while (i < len(sequences)):
	seq_id = sequences[i].description.split("::")
	seq_id = seq_id[0]
	seq_id = seq_id.split(" ")
	seq_id = seq_id[1] # contig id
	seq_id = seq_id.split(":")
	seq_id = seq_id[0]
	if (seq_id in organisms_dict):
		organisms_dict[seq_id].append(sequences[i])
	else:
		organisms_dict[seq_id] = [sequences[i]]
	i += 1
# get a list of sequences sorted by id.
organism_lists = list(organisms_dict.values())
print("sequences_sorted !!")
# for each organism list, check if respective sequences are the same length. eliminate duplicates.
# map the length as a key for erach element
# use the set operator to withdraw a condensed set of non-redundant elements
j = 0
ret_list = []
while (j < len(organism_lists)):
	i = 0
	non_redundant_sequences = []
	organism_dict = {}
	organism_lens = []
	for organism in organism_lists[j]:
		organism_dict[len(organism)] = organism
	while (i < len(organism_lists[j])):
		organism_lens.append(len(organism_lists[j][i]))
		i += 1
	organism_lens = list(set(organism_lens))
	for numb in organism_lens:
		non_redundant_sequences.append(organism_dict[numb])
	ret_list.append(non_redundant_sequences)	
	j += 1
real_ret_list = []
for real in ret_list:
	real_ret_list.extend(real)
print(len(real_ret_list))		
SeqIO.write(real_ret_list, "de_duplicated_" + seq_url, "fasta")
