# samtools pipeline

genomes=($( ls bwa_contigs/))
index_cmds=($( ls index_bwa/))
file_len=${#genomes[*]}
i=0
while [ $i -le $file_len ] 
do 
cat "index_bwa/"${index_cmds[i]} | xargs -n 1 -I {} -P 14 samtools faidx "bwa_contigs"/${genomes[i]} {} >> "wgs_contigs_flanking_windows.fasta"
(( i++ )) 
done

