# convert fasta -> table

from Bio import SeqIO

sequences = list(SeqIO.parse("blast_reports.fasta", "fasta"))
seq_descriptors = []

for sequ in sequences:
	seq_descriptors.append(sequ.description)
seq_ids = []
seq_protein = []
seq_organism = []
for sequ in seq_descriptors:
	seq_id = sequ.split(" ")
	seq_ids.append(seq_id[0])
	seq_id = seq_id[1:]
	seq_id = "".join(seq_id)
	seq_id = sequ.split("[")
	seq_protein.append(seq_id[0])
	seq_organism.append(seq_id[1])
seq_organism2 = []
for sequ in seq_organism:
	seq_organism2.append(sequ[:-1])
seq_prot2 = []
for sequ in seq_protein:
	seq_prot = sequ.split(" ")
	seq_prot = seq_prot[1]
	seq_prot2.append(seq_prot)	
i = 0
while (i < len(seq_ids)):
	print (seq_ids[i] + "," + seq_prot2[i] + "," + seq_organism2[i])	
	i += 1		