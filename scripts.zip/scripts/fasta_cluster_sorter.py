# first need to create a function to sort clusters by total number.
# then need to isolate just one representative from each cluster.

from Bio import SeqIO
import sys

seq_url = sys.argv[1]
sequences = list(SeqIO.parse(seq_url, "fasta"))

# count_duplicates of the first letter of id. Create tuple as count and list of lists of clusters
print(len(sequences))
def count_duplicates(fasta_clusters):
	previous_query_sequence = fasta_clusters[0].id.split("|")
	previous_query_sequence = int(previous_query_sequence[0])
	print(previous_query_sequence)
	previous_fasta_sequence = fasta_clusters[0]
	i = 1
	ret_list = []
	count = 1
	local_cluster = [fasta_clusters[0]] # initialise to the first sequence
	while(i < len(fasta_clusters)):
		query_number = fasta_clusters[i].id.split("|")
		query_number = int(query_number[0])
	#	print(query_number)
		if (previous_query_sequence == query_number):
			local_cluster.append(fasta_clusters[i])
			count += 1
		else:
			ret_list.append((local_cluster, count))
	#		print(count)
			count = 1
			previous_query_sequence = fasta_clusters[i].id.split("|")
			previous_query_sequence = int(previous_query_sequence[0])
			local_cluster = [fasta_clusters[i]]
		i+=1			
	ret_list.append((local_cluster, count))
	return ret_list

sorted_clusters = count_duplicates(sequences)
sorted_clusters.sort(key= lambda x: x[1], reverse=True)	
sorted_list = []
for cluster in sorted_clusters: # [()}]
#	print(cluster)
	for sequence in cluster[0]:
	#	print(cluster)
	#	print(sequence)
		sorted_list.append(sequence)
#print(sorted_list)		
SeqIO.write(sorted_list, "sorted_fasta_proteins.fa", "fasta")		

print(len(sorted_clusters))
ret_list_2_clusters = []
for sequ in sorted_clusters:
	if(sequ[1] > 1):
		ret_list_2_clusters.append(sequ[0])

rep_list = []
print(len(ret_list_2_clusters))
for sequ in ret_list_2_clusters:
	rep_list.append(sequ[0])	# this should crash if clusters only contain one element
print(len(rep_list))
print(rep_list)
SeqIO.write(rep_list, "representative_proteins.fasta", "fasta")			

# try  a completely different way
# 1 sort based