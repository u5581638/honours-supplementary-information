# sequence_hits
# extract the positive hits from csv

import csv
import sys

query_cas_sequences = sys.argv[1]
cas_hit_table = sys.argv[2]
ret_name = sys.argv[3]

with open(query_cas_sequences, newline='') as csvfile: #open query sequences
	query_reader = list(csv.reader(csvfile))
cas_ids = []
# list of queries
for row in query_reader:
	cas_ids.append(row[0])

with open(cas_hit_table, newline='') as csvfile2:
	cas_table = list(csv.reader(csvfile2))

ret_entries = []

for cas_id in cas_ids:
	cas_matches = []
	for entry in cas_table:
		if (cas_id == entry[0]):
			cas_matches.append(entry)
	ret_entries.append((cas_id,cas_matches))

with open(ret_name, "w") as csvfile3:
	spamwriter = csv.writer(csvfile3)
	for sequ in ret_entries:
		spamwriter.writerow(sequ[1])	
			
