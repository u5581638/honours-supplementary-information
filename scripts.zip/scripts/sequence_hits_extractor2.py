# sequence_hits
# extract the positive hits from csv

import csv
import sys

query_cas_sequences = sys.argv[1]
#cas_hit_table = sys.argv[2]
genome_sequence_url = sys.argv[2]
ret_seq_name = sys.argv[3]

with open(query_cas_sequences, newline='') as csvfile: #open query sequences
	query_reader = list(csv.reader(csvfile))
cas_ids = []
# list of queries
for row in query_reader:
	cas_ids.append(row[0])
#	print(row[0])


ret_entries = cas_ids

# this is the problematic part
# go straight to the script for taking relevant sequences out

from Bio import SeqIO
genome_sequences = list(SeqIO.parse(genome_sequence_url, "fasta"))
# best to dictionarilise this
ret_list = []
genome_sequence_dict = {}
for sequ in genome_sequences:
	genome_sequence_dict[sequ.id] = sequ

for seq_id in ret_entries:
	if seq_id in genome_sequence_dict:
		ret_list.append(genome_sequence_dict[seq_id])
SeqIO.write(ret_list, ret_seq_name, "fasta")		
