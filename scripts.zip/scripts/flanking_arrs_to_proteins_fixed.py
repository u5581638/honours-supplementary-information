#extract hypothetical proteins corresponding to flanking regions
from Bio import SeqIO
import re
import pickle
import itertools
import sys

effector_url = sys.argv[1]
seq_collection_url = sys.argv[2]
proteins = list(SeqIO.parse(effector_url, "fasta"))
flanking_contigs = list(SeqIO.parse(seq_collection_url, "fasta"))
protein_dict = [] # may be a more efficent implementation - leave unused for now
#generate a dictionary of proteins
#as these are the effectors, all proteins should come from different arrays 
for protein in proteins:
	protein_id = protein.description.split("::")
	protein_id = protein_id[0]
	protein_id = protein_id.split(" ")
	protein_id = protein_id[1]

	print(protein_id)
	protein_dict.append([protein_id,protein])

ret_list = []
for contig in flanking_contigs:
	for protein in protein_dict:
		if(contig.id == protein[0]):
			ret_list.append(protein[1])
print(len(ret_list))

SeqIO.write(ret_list, "novel_proteins_fixed.fasta", "fasta")


