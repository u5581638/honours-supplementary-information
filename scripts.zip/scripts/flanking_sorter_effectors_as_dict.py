# article to take a list of effector proteins and return 
# identified proteins of the same id and flanking region

from Bio import SeqIO
import re
import pickle
import itertools
import sys

effector_url = sys.argv[1]
seq_collection_url = sys.argv[2]
effectors = list(SeqIO.parse(effector_url, "fasta"))
seq_collection = list(SeqIO.parse(seq_collection_url, "fasta"))
seq_collection_dict = [] # may be a more efficent implementation - leave unused for now

#build a list containing just the flanking region range
i = 0
while (i < len(seq_collection)):
	seq_id = seq_collection[i].description.split("::")
	seq_id = seq_id[0]
	seq_id = seq_id.split(" ")
	seq_collection[i].description = seq_id[1]
	i += 1
# might be a way to hash this instead
print ("List built of unknown orfs")
ret_list = []
i = 0

# build a dictionary of the effector proteins - should have unique flanking
# region identifiers
effector_protein_dict = {}

for effector in effectors:
	effector_id = effector.description.split("::")
	effector_id = effector_id[0]
	effector_id = effector_id.split(" ")
	effector_id = effector_id[1]
	effector_protein_dict[effector_id] = effector

print ("Dict built of effector proteins")
count = 0
for sequ in seq_collection:	
	#print("Hi")
	sp_flanking_region = []
	if (sequ.description in effector_protein_dict): # want key of effector to match seq.description
		count += 1
		print(count)
		ret_list.append(sequ)
	i += 1		
#pickle.dump(ret_list, open("ancillary_proteins_to_effectors.p", "wb"))
print(len(ret_list))

#print(len(flat_ret))
SeqIO.write(ret_list, "all_ancillary_to" + effector_url, "fasta")


