# match_matched_proteins to the set
from Bio import SeqIO
import sys

match_set_url = sys.argv[1]
within_set_url = sys.argv[2]

match_set = list(SeqIO.parse(match_set_url, "fasta"))
within_set = list(SeqIO.parse(within_set_url, "fasta"))

