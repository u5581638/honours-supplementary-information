# true while loop implementation
# in each folder
i=1
while [ $i -le 16 ] 
do
k=1
arr=($(ls partition$i/))
arr_len=${#arr[*]}
let "folder_size = $arr_len / 2"
arr_index=1
while [ $k -le 2 ] 
do 
mkdir partition$i/sub_partition$k/
l=1
while [ $l -le $folder_size ] 
do 
mv ${arr[arr_index]} partition$i/sub_partition$k/
(( arr_index++ ))
(( l++ ))
done
(( k++ ))
done
(( i++ )) 

