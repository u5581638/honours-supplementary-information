# contigs from arr

from Bio import SeqIO

crisprs = list(SeqIO.parse("bwa_arr.fasta", "fasta"))
contigs = list(SeqIO.parse("archeae.fna", "fasta"))

i=0 
k=0

contigs_list = []
while (i < len(contigs)):
	while (k < len(crisprs)):
	#	print (crisprs[k].id, )
		if (contigs[i].seq.find(crisprs[k].seq) != -1):
			contigs_list.append(contigs[i])
			print ("Hello")
		k += 1
	print ("Hi")	
	i += 1
print (contigs_list)
SeqIO.write(contigs_list, "remaining_contigs.fasta", "fasta")				
