#entrez reader

from Bio import Entrez
from Bio import SeqIO
import sys

sys_url = sys.argv[1]
#import the 2552 from the final_sequence_alignment
cas9_sequences = list(SeqIO.parse(sys_url, "fasta"))

cas9_contigs = []
i = 40
while i < 516:
	Entrez.email = "u5581638@anu.edu.au"
#	print(cas9_sequences[i].id)
	record = Entrez.read(Entrez.elink(db="nucleotide", dbfrom="protein", id=cas9_sequences[i].id))
	#print(record[0])
	first_entry = record[0]
	setdb = first_entry['LinkSetDb']
	setdb=setdb[0]
	setdb=setdb['Link']
	setdb=setdb[0]
	setdb=setdb['Id']
	print(setdb)
	handle = Entrez.efetch(db="nucleotide", id=setdb, rettype="fasta", retmode="text" )
	nuc_sequence = SeqIO.read(handle, "fasta")
	with open(sys.argv[1], "a") as outhandle:
		SeqIO.write(nuc_sequence, outhandle, "fasta")
#	cas9_contigs.append(nuc_sequence)
	i += 1

# that's how you extract the nucleotide sequence
# now we want to do this for all

