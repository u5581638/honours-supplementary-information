# duplicate id remover

from Bio import SeqIO
import sys

seq_url = sys.argv[1]
sequences = list(SeqIO.parse(seq_url, "fasta"))

seq_ids = []

for sequ in sequences: 
	seq_ids.append(sequ.id)

print(len(seq_ids))
seq_ids = list(set(seq_ids))
print(len(seq_ids))

sequences_dict = {}

for sequ in sequences:
	sequences_dict[sequ.id] = sequ

	
