# cas9 flanking region extractor

from Bio import SeqIO
import sys
import csv

seq_url = sys.argv[1]

sequence = SeqIO.read(seq_url, "fasta")

with open("non_redundant_" + seq_url + ".csv", newline='') as csvfile:
	cas9_hits = list(csv.reader(csvfile))
# first sort table by evalue

cas9_hits.sort(key=lambda a: a[6])

index = cas9_hits[0][6]
upperbound = index + 20000
lowerbound = index - 40000

if (lowerbound < 0 and upperbound > len(sequence)):
	SeqIO.write(sequence, seq_url + "_40kb_window.fasta", "fasta")
elif (lowerbound > 0 and upperbound > len(sequence)):
	SeqIO.write(sequence[lowerbound:], seq_url + "_40kb_window.fasta", "fasta")
elif (lowerbound < 0 and upperbound < len(sequence)):
	SeqIO.write(sequence[:upperbound], seq_url + "_40kb_window.fasta", "fasta")
else:
	SeqIO.write(sequence[lowerbound:upperbound], seq_url + "_40kb_window.fasta", "fasta")			