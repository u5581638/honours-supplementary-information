# sequence_splitter

from Bio import SeqIO
import sys

seq_url = sys.argv[1]
sequences = list(SeqIO.parse( seq_url,"fasta"))

i = 0
while(i < len(sequences)):
	print(sequences[i])
	print(i)
	SeqIO.write(sequences[i], "protein_1_no_duplicates_" + str(i), "fasta")
	i += 1
