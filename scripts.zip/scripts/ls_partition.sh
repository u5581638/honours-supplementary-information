# running PILERCR \
# access each folder upon which the master_file_is_located
# run pilercr, using the filename as input.

arr=($(ls))
arr_len=${#arr[*]}
let "folder_size = $arr_len / 4"
arr_index=1
i=1
echo $folder_size
while [ $i -le 4 ] 
do 
k=1
mkdir partition$i/
while [ $k -le $folder_size ] 
do 
mv ${arr[arr_index]} partition$i/ 
(( arr_index++ ))
(( k++ )) 
done 
cat partition$i/*.gz >> master_pat_file$i.gz
(( i++ ))
done
