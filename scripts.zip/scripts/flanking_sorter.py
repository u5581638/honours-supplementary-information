# article to take a list of effector proteins and return 
# identified proteins of the same id and flanking region

from Bio import SeqIO
import re
import pickle
import itertools
import sys

effector_url = sys.argv[1]
seq_collection_url = sys.argv[2]
effectors = list(SeqIO.parse(effector_url, "fasta"))
seq_collection = list(SeqIO.parse(seq_collection_url, "fasta"))
seq_collection_dict = {} # may be a more efficent implementation - leave unused for now

for sequ in seq_collection:
# might be a way to hash this instead
ret_list = []
i = 0
count = 0
while (i < len(effectors)):
	effector_id = effectors[i].description.split("::")
	effector_id = effector_id[0]
	effector_id = effector_id.split(" ")
	effector_id = effector_id[1]
	print("Hi")
	sp_flanking_region = []
	k = 0
	while (k < len(seq_collection)):
		seq_id = seq_collection[k].description.split("::")
		seq_id = seq_id[0]
		seq_id = seq_id.split(" ")
		seq_id = seq_id[1]
		if (effector_id == seq_id):
			sp_flanking_region.append(seq_collection[k]) # this is the main line
			count += 1
			print(count)
		k += 1
	ret_list.append(sp_flanking_region)	
	i += 1		
pickle.dump(ret_list, open("ancillary_proteins_to_effectors.p", "wb"))
print(len(ret_list))
flat_ret = list(itertools.chain(*ret_list))
SeqIO.write(flat_ret, "ancillary_proteins_to_effectors.fa", "fasta")


