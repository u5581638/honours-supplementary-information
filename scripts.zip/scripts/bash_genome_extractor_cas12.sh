genome_arr=($( find master* )) # would be useful if files were listed in the same order
genome_arr_len=${#genome_arr[*]} 
csv_arr=($( find hits_* )) #may need to change path
csv_arr_len=${#genome_arr[*]}
echo ${genome_arr[*]} # check order
echo ${csv_arr[*]} # check order
i=0
seq_index=0
while [ $i -lt $csv_arr_len ] 
do 
k=0
split -b 500m ${genome_arr[i]}
split_files=($( find x* ))
split_files_len=${#split_files[*]}
while [ $k -lt $split_files_len ] 
do 
python3.6 sequence_hits_extractor.py cas12_hits.csv ${csv_arr[i]} ${split_files[k]} "seq_results"$seq_index
(( k++ ))
(( seq_index++ ))
done 
(( i++ ))
rm x*
done



