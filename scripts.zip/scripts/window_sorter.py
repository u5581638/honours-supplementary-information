# alogrithm to split a single concatenated file into two files based on whether the contig is within 20kb
# are the contigs likely to be full of 'N' chars
from Bio import SeqIO
import re

file = open("archaea_ref_genome.fna", "r")
ref_genomes = list(SeqIO.parse(file, "fasta"))
 
# need convert ref_genomes to dict

ref_denomes_dict = {}

for ref_genome in ref_genomes:
	ref_denomes_dict[ref_genome.id] = ref_genome


genomes = list(SeqIO.parse("master_crispr_seq.fna", "fasta"))

# match by id and find ref genomes by length
genome_list_lengths = [] # should be in order of all genomes
for genome in genomes:
	genome_list_lengths.append(len(ref_denomes_dict[genome.id].seq))

condensed_list = []
i = 0

bwa_arr = []
extract_arr = []
id_list_bwa = []
seq_index_list_bwa = []
id_list_extract = []
seq_index_list_extract = [] 

while (i < len(genomes)):
	pattern = re.compile("Pos=.*]")
	index = re.search(pattern, genomes[i].description)
#	print (index)
#	print (index.group(0))
	index = index.group(0)
	index = int(index[4:-1]) # check indexing
#	print (index)
	print(len (genomes[i]))
	if (index < 20000 or genome_list_lengths[i] - index < 20000):
		bwa_arr.append(genomes[i])
		id_list_bwa.append(genomes[i].id)
		seq_index_list_bwa.append(index)
	else:
        extract_arr.append(genomes[i])
        id_list_extract.append(genomes[i].id)
		seq_index_list_extract.append(index)
	i += 1

SeqIO.write(bwa_arr, "bwa_arr.fasta", "fasta")
SeqIO.write(extract_arr, "extraction_arr.fasta", "fasta")

extract_file = open("extraction_indexes.txt", "w")
i = 0
extract_cat = []
while (i < len(id_list_extract)):
        print (id_list_extract[i])
	extract_cat.append(id_list_extract[i] + ":" + str(seq_index_list_extract-20000) + "-" + str(seq_index_list_extract+20000))
	i += 1
extract_file.write("".join(extract_cat))	
extract_file.close()

bwa_file = open("bwa_indexes.txt", "w")
i = 0
bwa_cat = []
while (i < len(id_list_bwa)):
	bwa_cat.append(id_list_bwa[i] + ":" + str(seq_index_list_bwa[i]-20000) + "-" + str(seq_index_list_bwa[i]+20000) )
	i += 1

i = 0

extract_file.write(extract_arr)
bwa_file.write(bwa_arr)

# may have to filter Ns if these are in contigs.			
